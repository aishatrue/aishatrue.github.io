const clock = document.querySelector('h2#clock');

function getClock(){
    const date = new Date();
    const hours = String(date.getHours()).padStart(2,"0");
    const minutes = String(date.getMinutes()).padStart(2,"0");
    const seconds = String(date.getSeconds()).padStart(2,"0");
 
    if(9<=parseInt(hours)&& parseInt(hours)<=18){
        clock.innerText=`지금은 한창 카페인이 부족하고 졸린, ${hours}시 ${minutes}분 ${seconds}초  입니다.`;
    }else if(18<parseInt(hours)&& parseInt(hours)<24){
        clock.innerText=`노예에게 유일하게 주어지는 자유시간인, ${hours}시 ${minutes}분 ${seconds}초  입니다.`;

    }else{
        clock.innerText=`지금 잠을 자고있지 않다면 큰일이에요..지금 시간은 무려, ${hours}시 ${minutes}분 ${seconds}초  입니다.`;
    }

    // clock.innerText=`${hours}:${minutes}:${seconds}`;
}


getClock();
setInterval(getClock,1000);